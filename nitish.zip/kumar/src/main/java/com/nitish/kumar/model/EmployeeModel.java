package com.nitish.kumar.model;

public class EmployeeModel {
private String city;
	
	private Long empCount;
	
	private String skills;
	


	
	public EmployeeModel(String city, Long empCount) {
		super();
		this.city = city;
		this.empCount = empCount;
	}
	


	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Long getEmpCount() {
		return empCount;
	}

	public void setEmpCount(Long empCount) {
		this.empCount = empCount;
	}



	public String getSkill() {
		return skills;
	}



	public void setSkill(String skill) {
		this.skills = skill;
	}

}
