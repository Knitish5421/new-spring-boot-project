package com.nitish.kumar.model;

public class ModelForState {
	
	private Long empCount;
	
	private String state;
	
	public ModelForState(String state, Long empCount) {
		super();
		this.state = state;
		this.empCount = empCount;
		
	}

	public Long getEmpCount() {
		return empCount;
	}

	public void setEmpCount(Long empCount) {
		this.empCount = empCount;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}